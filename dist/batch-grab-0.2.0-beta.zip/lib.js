// Pure helpers: no Chrome APIs here, so they can be unit-tested in Node.

export const GROUPS = {
  Images: ["jpg", "jpeg", "png", "gif", "webp", "avif", "bmp", "svg", "tif", "tiff"],
  Documents: ["pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "epub", "mobi"],
  Archives: ["zip", "rar", "7z", "tar", "gz"],
  Media: ["mp3", "wav", "flac", "m4a", "ogg", "mp4", "webm", "mov", "mkv", "avi"],
};

export function parseUrl(u) {
  let url;
  try { url = new URL(u); } catch { return null; }
  let last = url.pathname.split("/").filter(Boolean).pop() || "";
  try { last = decodeURIComponent(last); } catch { /* keep raw */ }
  const dot = last.lastIndexOf(".");
  const hasExt = dot > 0 && last.length - dot <= 6;
  return {
    url: url.href,
    host: url.hostname.replace(/^www\./, ""),
    base: hasExt ? last.slice(0, dot) : last,
    ext: hasExt ? last.slice(dot + 1).toLowerCase() : "",
  };
}

export function groupOf(ext) {
  if (!ext) return "Pages";
  for (const [name, list] of Object.entries(GROUPS)) if (list.includes(ext)) return name;
  return "Other";
}

export function sanitize(s) {
  let clean = String(s).normalize("NFKC")
    .replace(/[\u202a-\u202e\u2066-\u2069]/g, "")
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, "_")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/^\.+/, "")
    .replace(/[. ]+$/, "")
    .slice(0, 100).replace(/[. ]+$/, "");
  if (/^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(clean)) clean = "_" + clean;
  return clean;
}

export function safeFilename(value, ext = "") {
  let name = String(value || "").trim();
  const dot = name.lastIndexOf(".");
  if (ext && dot > 0 && Object.values(GROUPS).flat().includes(name.slice(dot + 1).toLowerCase())) name = name.slice(0, dot);
  name = sanitize(name) || "document";
  return ext ? `${name}.${ext.toLowerCase()}` : name;
}
export function safeFolder(value) {
  return String(value || "").split(/[\\/]/).map(sanitize).filter(Boolean).slice(0, 6).join("/");
}
export function suggest(item) {
  const generic = /^(?:download|view|open|read|click here|english|pdf|document|file)(?:\s+(?:pdf|document|file|now|here))?$/i;
  const clean = (s) => String(s || "").replace(/\s*[([](?:pdf|docx?|xlsx?|pptx?)[)\]]\s*$/i, "").replace(/\s+/g, " ").trim();
  const link = clean(item.text), nearby = clean(item.nearby);
  const title = link && !generic.test(link) ? link : nearby && !generic.test(nearby) ? nearby : item.base;
  return { name: safeFilename(title, item.ext), folder: sanitize(item.section || "Documents"), basis: title === link ? "Link text" : title === nearby ? "Nearby label" : "Original filename" };
}
export function prepareJobs(items, root = "Batch Grab", occupied = []) {
  const used = new Set(occupied.map((s) => s.normalize("NFKC").toLowerCase()));
  return items.map((item) => {
    const url = new URL(item.url);
    if (!/^https?:$/.test(url.protocol)) throw new Error("Only HTTP and HTTPS downloads are supported.");
    const ext = item.ext && /^[a-z0-9]{1,8}$/i.test(item.ext) ? item.ext : "";
    let name = safeFilename(item.name, ext);
    const folder = safeFolder([safeFolder(root), safeFolder(item.folder)].filter(Boolean).join("/"));
    const original = name;
    let count = 1, path = [folder, name].filter(Boolean).join("/");
    while (used.has(path.normalize("NFKC").toLowerCase())) {
      count++;
      const suffix = ext ? `.${ext}` : "";
      name = `${suffix ? original.slice(0, -suffix.length) : original} (${count})${suffix}`;
      path = [folder, name].filter(Boolean).join("/");
    }
    used.add(path.normalize("NFKC").toLowerCase());
    return { ...item, url: url.href, name, folder, path };
  });
}

export function buildName(pattern, item, n, total, now = new Date()) {
  const pad = String(n).padStart(String(total).length, "0");
  const date = now.toISOString().slice(0, 10);
  let out = String(pattern || "{name}")
    .replace(/\{n\}/g, pad)
    .replace(/\{name\}/g, item.base)
    .replace(/\{ext\}/g, item.ext)
    .replace(/\{host\}/g, item.host)
    .replace(/\{date\}/g, date);
  out = sanitize(out) || `file-${pad}`;
  if (item.ext && !out.toLowerCase().endsWith("." + item.ext)) out += "." + item.ext;
  return out;
}

export function buildFolder(pattern, item, now = new Date()) {
  const date = now.toISOString().slice(0, 10);
  return String(pattern || "")
    .replace(/\{host\}/g, item.host)
    .replace(/\{date\}/g, date)
    .split("/")
    .map(sanitize)
    .filter(Boolean)
    .join("/");
}

export function matchText(url, query) {
  const q = (query || "").trim();
  if (!q) return true;
  const m = q.match(/^\/(.+)\/([a-z]*)$/i);
  if (m) {
    try { return new RegExp(m[1], m[2] || "i").test(url); } catch { return true; }
  }
  return url.toLowerCase().includes(q.toLowerCase());
}

export function applyFilters(items, { groups, text, minWidth }) {
  return items.filter((it) => {
    if (!groups.has(it.group)) return false;
    if (!matchText([it.url, it.text, it.nearby, it.name].filter(Boolean).join(" "), text)) return false;
    if (minWidth > 0 && it.kind === "image" && it.w && it.w < minWidth) return false;
    return true;
  });
}

// Runs inside the web page (injected via chrome.scripting). Must be self-contained.
export function scanPage() {
  const seen = new Map();
  const add = (raw, kind, extra) => {
    if (!raw) return;
    let abs;
    try { abs = new URL(raw, document.baseURI).href; } catch { return; }
    if (!/^https?:/i.test(abs)) return;
    if (!seen.has(abs)) seen.set(abs, Object.assign({ url: abs, kind }, extra || {}));
  };
  const visible = (el) => !!el.getClientRects().length && getComputedStyle(el).visibility !== "hidden";
  const text = (el) => el && visible(el) ? (el.innerText || "").replace(/\s+/g, " ").trim().slice(0, 220) : "";
  document.querySelectorAll("a[href]").forEach((a) => {
    const row = a.closest("li, tr, dd, [data-document], .document, .document-card") || a.parentElement;
    let nearby = "";
    if (row) {
      const label = row.querySelector("[data-document-title], strong, h3, h4, th, .title");
      nearby = text(label) || text(row).replace(text(a), "").replace(/\s*[·|—-]?\s*(?:PDF\s*)?\d+(?:\.\d+)?\s*(?:KB|MB)\s*$/i, "").trim();
    }
    const section = a.closest("section, article, fieldset");
    add(a.getAttribute("href"), "link", { text: text(a), nearby, section: text(section?.querySelector("h1,h2,legend")), downloadName: a.getAttribute("download") || "", mime: a.getAttribute("type") || "" });
  });
  document.querySelectorAll("img").forEach((i) =>
    add(i.currentSrc || i.src, "image", { w: i.naturalWidth || 0, h: i.naturalHeight || 0 })
  );
  document.querySelectorAll("video[src], audio[src], source[src]").forEach((m) => add(m.src, "media"));
  return Array.from(seen.values());
}
