import { GROUPS, parseUrl, groupOf, buildName, buildFolder, applyFilters, scanPage, suggest, prepareJobs } from './lib.js';
const $ = id => document.getElementById(id);
const state = { items: [], selected: new Set(), groups: new Set(), source: '', jobs: [] };
let saveTimer;
const shown = () => applyFilters(state.items, { groups: state.groups, text: $('text').value, minWidth: Number($('minw').value) || 0 });
const selected = () => shown().filter(it => state.selected.has(it.url));
const rootFolder = () => buildFolder($('folder').value, { host: state.items[0]?.host || 'page' });
function persistDraft() {
  return chrome.storage.local.set({ draft: { items: state.items, selected: [...state.selected], groups: [...state.groups], source: state.source, root: $('folder').value, pattern: $('pattern').value, text: $('text').value, minw: $('minw').value } });
}
function saveDraft() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(persistDraft, 100);
}
function updateButton() {
  const rows = prepareJobs(selected(), rootFolder());
  $('go').disabled = rows.length === 0 || rows.length > 500;
  $('go').textContent = rows.length ? `Download ${rows.length} selected file${rows.length === 1 ? '' : 's'}` : 'Select files to download';
  $('preview').replaceChildren(...rows.map(row => { const li = document.createElement('li'); li.textContent = row.path; return li; }));
  $('previewCount').textContent = `Final paths (${rows.length}) — unsafe names and batch duplicates resolved`;
  if (rows.length > 500) $('status').textContent = 'Beta supports 500 files per batch. Select fewer files.';
  saveDraft();
}
function render() {
  const list = $('list');
  list.replaceChildren();
  const visible = shown();
  for (const it of visible) {
    const li = document.createElement('li');
    li.dataset.url = it.url;
    const cb = document.createElement('input');
    cb.type = 'checkbox'; cb.checked = state.selected.has(it.url);
    cb.setAttribute('aria-label', `Select ${it.text || it.base}`);
    cb.addEventListener('change', () => { cb.checked ? state.selected.add(it.url) : state.selected.delete(it.url); updateButton(); });
    const meta = document.createElement('div');
    const title = document.createElement('div'); title.className = 'name'; title.textContent = it.text || it.nearby || it.base;
    const source = document.createElement('div'); source.className = 'sub'; source.textContent = `${it.group} · ${it.basis} · ${it.url}${it.nearby ? ` · ${it.nearby}` : ''}`; source.title = source.textContent;
    const fields = document.createElement('div'); fields.className = 'row';
    for (const [field, label] of [['name', 'Filename'], ['folder', 'Subfolder']]) {
      const wrapper = document.createElement('label'); wrapper.textContent = label;
      const input = document.createElement('input'); input.type = 'text'; input.value = it[field]; input.dataset.field = field;
      input.setAttribute('aria-label', `${label} for ${it.text || it.base}`);
      input.addEventListener('input', () => { it[field] = input.value; updateButton(); });
      wrapper.append(input); fields.append(wrapper);
    }
    meta.append(title, source, fields); li.append(cb, meta); list.append(li);
  }
  if (!visible.length) { const li = document.createElement('li'); li.className = 'empty'; li.textContent = state.items.length ? 'Nothing matches these filters.' : 'No files found. Open a normal webpage and scan it.'; list.append(li); }
  $('count').textContent = `${state.items.length} found · ${visible.length} match filters`;
  updateButton();
}
function renderJobs() {
  const n = statuses => state.jobs.filter(j => statuses.includes(j.status)).length;
  $('queueSummary').textContent = `${n(['complete'])} completed · ${n(['queued', 'starting', 'in_progress'])} pending · ${n(['interrupted'])} failed`;
  $('jobs').replaceChildren(...state.jobs.slice().reverse().map(job => {
    const li = document.createElement('li'); li.dataset.jobId = job.id; li.dataset.status = job.status;
    const label = document.createElement('div'); label.textContent = `${job.status === 'complete' ? 'Completed' : job.status === 'interrupted' ? 'Failed' : job.status.replace('_', ' ')} · ${job.actualFilename || job.path}`; li.append(label);
    if (job.error) { const error = document.createElement('span'); error.className = 'error'; error.textContent = job.error; li.append(error); }
    if (job.status === 'interrupted' && !job.retried) {
      const retry = document.createElement('button'); retry.textContent = 'Retry';
      retry.addEventListener('click', async () => { const response = await chrome.runtime.sendMessage({ type: 'retry', id: job.id }); if (!response.ok) $('status').textContent = response.error; }); li.append(retry);
    }
    return li;
  }));
}
async function scan() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !/^https?:/.test(tab.url || '')) throw new Error('Open an HTTP(S) webpage and click the extension. Chrome system and store pages cannot be scanned.');
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: scanPage });
    state.items = (res.result || []).map(r => {
      const p = parseUrl(r.url);
      const hinted = parseUrl(`https://hint.invalid/${r.downloadName || ''}`)?.ext;
      if (!p) return null;
      if (!Object.values(GROUPS).flat().includes(p.ext)) {
        if (hinted && Object.values(GROUPS).flat().includes(hinted)) p.ext = hinted;
        else if (r.mime === 'application/pdf') p.ext = 'pdf';
      }
      const it = { ...r, ...p, group: groupOf(p.ext) };
      return { ...it, ...(it.group === 'Documents' ? suggest(it) : { name: buildName('{name}', it, 1, 1), folder: '', basis: 'Original filename' }) };
    }).filter(Boolean);
    state.source = tab.url; state.selected.clear(); $('source').textContent = state.source;
    $('status').textContent = 'Review suggestions, select files and check Final paths before downloading.';
    render();
  } catch (error) { $('status').textContent = error.message; $('count').textContent = 'Scan unavailable'; }
}
function filtersChanged() {
  const available = new Set(shown().map(it => it.url)); state.selected = new Set([...state.selected].filter(url => available.has(url))); render();
}
async function init() {
  const { draft, jobs = [] } = await chrome.storage.local.get(['draft', 'jobs']); state.jobs = jobs;
  state.groups = new Set(draft?.groups || ['Documents']);
  for (const group of [...Object.keys(GROUPS), 'Other', 'Pages']) {
    const label = document.createElement('label'), cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = state.groups.has(group);
    cb.addEventListener('change', () => { cb.checked ? state.groups.add(group) : state.groups.delete(group); filtersChanged(); }); label.append(cb, group); $('groups').append(label);
  }
  if (draft) {
    state.items = draft.items; state.selected = new Set(draft.selected); state.source = draft.source;
    for (const [id, key] of [['folder', 'root'], ['pattern', 'pattern'], ['text', 'text'], ['minw', 'minw']]) $(id).value = draft[key];
    $('source').textContent = state.source; render();
  } else await scan();
  renderJobs();
  await chrome.runtime.sendMessage({ type: 'getJobs' });
}
$('scan').addEventListener('click', scan);
$('text').addEventListener('input', filtersChanged); $('minw').addEventListener('input', filtersChanged);
$('folder').addEventListener('input', updateButton); $('pattern').addEventListener('input', saveDraft);
$('all').addEventListener('click', () => { shown().forEach(it => state.selected.add(it.url)); render(); });
$('none').addEventListener('click', () => { state.selected.clear(); render(); });
$('smart').addEventListener('click', () => { shown().filter(it => it.group === 'Documents').forEach(it => Object.assign(it, suggest(it))); render(); });
$('template').addEventListener('click', () => { const rows = shown(); rows.forEach((it, i) => { it.name = buildName($('pattern').value, it, i + 1, rows.length); it.basis = 'Custom template'; }); render(); });
$('go').addEventListener('click', async () => {
  $('go').disabled = true;
  try {
    clearTimeout(saveTimer);
    await persistDraft();
    const response = await chrome.runtime.sendMessage({ type: 'enqueue', root: rootFolder(), items: selected().map(it => ({ ...it, source: state.source })) });
    if (!response.ok) throw new Error(response.error);
    $('status').textContent = `${response.accepted} jobs saved. You can close this popup; pending jobs continue while Chrome is running.`;
  } catch (error) { $('status').textContent = error.message; }
  updateButton();
});
$('clearFinished').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'clearFinished' }));
$('downloads').addEventListener('click', () => chrome.tabs.create({ url: 'chrome://downloads/' }));
chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes.jobs) { state.jobs = changes.jobs.newValue || []; renderJobs(); } });
init().catch(error => { $('status').textContent = error.message; });
